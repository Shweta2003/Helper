package com.example.helper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.w3c.dom.Document;

import java.io.Console;
import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class register extends AppCompatActivity {
    private Button register;
    private EditText username;
    private EditText password;
    private TextView Loginb;

    CollectionReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

//        code to remove header
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

//        get data from user
        username = findViewById(R.id.username);
        password = findViewById(R.id.Password);
        register = findViewById(R.id.register);

        db = FirebaseFirestore.getInstance().collection("User_details");

//        go to login page if user already has account
        Loginb = findViewById(R.id.go_to_login);
        Loginb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(register.this,Login.class));
            }
        });



//        store the data into firestore database
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userdata = username.getText().toString();
                String passdata = password.getText().toString();
                Log.d("userdata",userdata);
                Log.d("password",passdata);
                if(TextUtils.isEmpty(userdata) || TextUtils.isEmpty(passdata)){
                    Toast.makeText(register.this,"Please fill all the details",Toast.LENGTH_SHORT).show();
                    username.setText("");
                    password.setText("");
                }
                else{
//                    this part of code is used to check whether document is present in collection or not
                    db.document(userdata).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {
                                    Toast.makeText(register.this,"User already exists.. try another name",Toast.LENGTH_SHORT).show();
                                    username.setText("");
                                    password.setText("");
                                } else {
                                    Map<String,String> v = new HashMap<>();
                                    v.put("username",userdata);
                                    v.put("password",passdata);
                                    db.document(userdata).set(v).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            Toast.makeText(register.this,"You are successfully registered!!",Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(register.this,MainActivity.class));
                                        }
                                    });
                                }
                            } else {
                                Log.d("TAG", "Error getting document: ", task.getException());
                            }
                        }
                    });

                }
            }
        });
    }


}
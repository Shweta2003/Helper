package com.example.helper;

import com.android.volley.Response;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    private Button logout;

    Context context = this;
    private Button start;

    CollectionReference db;

    String currIp = "";

    String hello = "hey";



    private TextView ipadd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        start = findViewById(R.id.start);
        logout = findViewById(R.id.logout);
        ipadd = (TextView) findViewById(R.id.getip);

        db = FirebaseFirestore.getInstance().collection("currently logged in");

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, register.class);
                startActivity(intent);
            }
        });

//      get ip address
        String url = "https://api.ipify.org";
        RequestQueue queue = Volley.newRequestQueue(context);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        currIp = response;
                        ipadd.setText(response);
                        checklog();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Error", error.toString());
            }
        });

        queue.add(stringRequest);

//        check ip with the currently logged in users to see if he/she is already logged in


//        db.document(currIp).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
//                if (task.isSuccessful()) {
//                    DocumentSnapshot document = task.getResult();
//                    if (document.exists()) {
//                        Toast.makeText(MainActivity.this,"user_found",Toast.LENGTH_SHORT).show();
//                    } else {
//                        Toast.makeText(MainActivity.this,"user_not_found",Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    Log.d("TAG", "Error getting document: ", task.getException());
//                }
//            }
//        });

//        requestWindowFeature(Window.FEATURE_NO_TITLE);

    }

    protected void checklog(){
        db.document(currIp).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        startActivity(new Intent(MainActivity.this,AlarmNote.class));
                    } else {
                        startActivity(new Intent(MainActivity.this,Login.class));
                    }
                } else {
                    Log.d("TAG", "Error getting document: ", task.getException());
                }
            }
        });
    }
}